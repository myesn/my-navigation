const title = "我是标题";
const navs = [
	// 点击后直接跳转
    {
        "type": "url",
        "name": "百度",
        "url": "https://baidu.com"
    },
	// 分组按钮，点击后出现弹出层
    {
		"type": "group",
		"name": "其他网站",
		"children": [
			{
				"type": "url",
				"name": "Google",
				"url": "https://google.com"
			}
		]
    }
]